from fastapi import FastAPI, Request, Form
from fastapi.templating import Jinja2Templates
import joblib
import pandas as pd

# Initialisation de l'app
app = FastAPI()

# Templates (HTML)
templates = Jinja2Templates(directory="app/templates")

# Charger le modèle et le scaler
model = joblib.load("model/model.pkl")
scaler = joblib.load("model/scaler.pkl")


# Route principale (affichage page HTML)
@app.get("/")
def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})


# Route de prédiction (formulaire HTML)
@app.post("/predict")
def predict(
    request: Request,
    client_enc: float = Form(...),
    hostname_enc: float = Form(...),
    alias_count: float = Form(...),
    address_count: float = Form(...)
):
    # Création du DataFrame
    df = pd.DataFrame([[
        client_enc,
        hostname_enc,
        alias_count,
        address_count
    ]], columns=[
        "client_enc",
        "hostname_enc",
        "alias_count",
        "address_count"
    ])

    # Scaling
    scaled = scaler.transform(df)

    # Prédiction
    prediction = model.predict(scaled)

    # Résultat
    result = "Anomaly 🚨" if prediction[0] == -1 else "Normal ✅"

    # Retour vers le template avec résultat
    return templates.TemplateResponse("index.html", {
        "request": request,
        "result": result
    })