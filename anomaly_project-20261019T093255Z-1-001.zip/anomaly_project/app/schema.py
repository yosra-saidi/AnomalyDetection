from pydantic import BaseModel

class InputData(BaseModel):
    client_enc: float
    hostname_enc: float
    alias_count: float
    address_count: float